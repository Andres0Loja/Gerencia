@javax.xml.bind.annotation.XmlSchema(namespace = "http://SOAP.ups.edu.ec/")
package ec.edu.ups.soap;
